"""Trust boundary: where authority actually comes from.

The red-team finding this module closes:

    TrajectoryState.to_eval_dict() splices **args into the same namespace the
    Ω rules read their control flags from. Every deployment rule ends in
    `not _authorized(s)`, and `_authorized()` reads that namespace. So a caller
    that writes `{"authorized": true}` into its own arguments authorises itself.
    12 of 13 blocked catastrophic actions became executable that way.

The fix is a strict separation:

  * REQUEST metadata (anything the caller can write) is DATA. It is quarantined
    out of the authority namespace before evaluation and retained only as a
    forgery signal.
  * AUTHORITY is derived from a server-side SecurityContext: an authenticated
    principal, policy state, and cryptographically verified approval artifacts
    bound to a specific canonical action hash.

Nothing a caller can write can widen what it is allowed to do.
"""

from __future__ import annotations

import hashlib
import hmac
import time
from dataclasses import dataclass, field, replace
from typing import Any, Optional

from morrison_governance.kernel.canonical import (
    action_hash, canonicalize, semantic_action_hash,
)

# ─────────────────────────────────────────────────────────────
# Quarantined authority fields
# ─────────────────────────────────────────────────────────────
# Any request field that could REDUCE restriction if believed. These are
# stripped from the evaluation namespace and can never confer authority.
# Fields that only ever INCREASE suspicion (e.g. a requested `role: admin`)
# are deliberately NOT quarantined — they are evidence for detection and
# removing them would blind the privilege-escalation rules that already work.
AUTHORITY_FIELDS = frozenset({
    # approval / authorisation assertions
    "authorized", "authorised", "approved", "approval", "approved_by",
    "approver", "verified", "sanctioned", "change_approved", "admin_authorized",
    "authorization", "authorisation", "auth", "consent", "consented",
    "reviewed", "signed_off", "signoff", "override", "override_approved",
    "break_glass", "emergency_approved", "exception_approved", "waiver",
    # trust / boundary assertions
    "destination_internal", "is_internal", "internal", "destination_external",
    "external", "trusted", "is_trusted", "privileged", "is_privileged",
    "safe", "is_safe", "sanitized", "sanitised", "anonymized", "anonymised",
    "deidentified", "de_identified", "encrypted",
    # policy-bound comparison values the caller must not choose
    "threshold", "limit", "max_amount", "risk_score", "identity_score",
    "confidence", "severity_override", "policy", "policy_override",
    # identity assertions (identity comes from the session, never the payload)
    "actor", "principal", "user_id", "tenant", "tenant_id", "on_behalf_of",
    "requested_by", "session_customer", "impersonate",
})

# ─────────────────────────────────────────────────────────────
# Authority by SHAPE, not by spelling
# ─────────────────────────────────────────────────────────────
#
# AUTHORITY_FIELDS is an exact-name set, and an exact-name set only catches
# the spellings someone thought of. On 2026-09-20 a live run presented
# `approval_id=APR-7741-C9F2` in a tool call: `approved` is on the list,
# `approval_id` is not, so the claim was neither quarantined nor recorded.
# The capability gate still refused the action — nothing executed — but the
# evidence record said only "no approval artifact presented" when what had
# actually happened was "a forged one was presented and carried no weight".
# For an auditable boundary that is the wrong receipt.
#
# So authority is recognised by the SHAPE of the name: a root that names an
# authority instrument, optionally carrying structural affixes. This is the
# same move `_sec_authorized()` already makes in domains.py — shape selects
# among claims; it never establishes one.
#
# Roots are deliberately narrow. `grant` and `permit` are NOT roots: a
# `grant_amount` or a `permit_number` is ordinary domain data, and
# quarantining it would strip a real field out of the evaluation namespace to
# catch a claim nobody has made.
_AUTHORITY_ROOTS = frozenset({
    "approval", "approvals", "approved", "authorization", "authorisation",
    "authorized", "authorised", "signoff", "attestation", "attested",
    "waiver", "override", "consent", "consented", "sanction", "sanctioned",
    "clearance", "authorisations", "authorizations",
    # collapsed two-word roots, see _collapse_roots
    "signoff", "breakglass",
})

# Roots that are written as two words as often as one. Without this,
# `signed_off_by` reads as [signed, off, by] — no root — while `signoff_id`
# matches, which is an arbitrary distinction to draw in an audit boundary.
_ROOT_PAIRS = {
    ("sign", "off"): "signoff",
    ("signed", "off"): "signoff",
    ("break", "glass"): "breakglass",
}

# Structural parts that can hang off a root without changing what it asserts.
# `approval_id`, `approval_token`, `approved_by`, `override_ref` are all the
# same claim wearing different clothes.
_AUTHORITY_AFFIXES = frozenset({
    "id", "ids", "ref", "refs", "reference", "code", "token", "no", "num",
    "number", "key", "hash", "sig", "signature", "url", "uri", "link",
    "by", "at", "on", "from", "for", "status", "state", "level", "type",
    "artifact", "artefact", "record", "receipt", "ticket", "case", "doc",
    "is", "has", "was", "flag", "value", "field", "header", "chain",
})

_WORD = __import__("re").compile(r"[^a-z0-9]+")
# camelCase and PascalCase carry the same claim as snake_case. `approvalId`
# reached this code as one token and slipped through the first version of this
# matcher; JSON tool-call payloads use camelCase routinely.
_CAMEL = __import__("re").compile(r"(?<=[a-z0-9])(?=[A-Z])")


def _collapse_roots(toks: list) -> list:
    out, i = [], 0
    while i < len(toks):
        pair = (toks[i], toks[i + 1]) if i + 1 < len(toks) else None
        if pair in _ROOT_PAIRS:
            out.append(_ROOT_PAIRS[pair])
            i += 2
        else:
            out.append(toks[i])
            i += 1
    return out


def _name_tokens(key) -> list:
    spaced = _CAMEL.sub("_", str(key).strip())
    return _collapse_roots(
        [tok for tok in _WORD.split(spaced.lower()) if tok])


def is_authority_shaped(key) -> bool:
    """True when a field NAME asserts an authority instrument.

    Detection only. Recognising a claim never honours it — a recognised claim
    is quarantined and recorded, which is strictly less power than an
    unrecognised one, since an unrecognised name stays in the namespace.

    A name matches when it contains an authority root and every other token is
    structural. `approval_id` matches; `signature` alone does not (a document
    signature is ordinary data); `exception_message` does not (`message` is
    not structural); `grant_amount` does not (`grant` is not a root).
    """
    toks = _name_tokens(key)
    if not toks:
        return False
    if "_".join(toks) in AUTHORITY_FIELDS:
        return True
    if not any(tok in _AUTHORITY_ROOTS for tok in toks):
        return False
    return all(tok in _AUTHORITY_ROOTS or tok in _AUTHORITY_AFFIXES
               for tok in toks)


# Fields whose presence is itself a signal worth recording loudly.
_FORGERY_SIGNIFICANT = frozenset({
    "authorized", "authorised", "approved", "approved_by", "approver",
    "verified", "sanctioned", "change_approved", "admin_authorized",
    "destination_internal", "is_internal", "internal", "trusted",
    "privileged", "break_glass", "threshold", "override",
})


def quarantine_authority(call: dict) -> tuple[dict, dict]:
    """Split a canonical call into (clean_call, quarantined_fields).

    `clean_call` is what the Ω rules evaluate. `quarantined_fields` is retained
    as evidence — a caller asserting `authorized: true` has told us something
    important about itself, and we record it rather than discarding it.
    """
    canon = canonicalize(call)
    quarantined: dict[str, Any] = {}

    def escape(key):
        return str(key).replace("~", "~0").replace("/", "~1")

    def walk(value, path=()):
        if isinstance(value, dict):
            clean = {}
            for key, child in value.items():
                label = str(key)
                if label.strip().lower() in AUTHORITY_FIELDS or is_authority_shaped(label):
                    evidence_key = label if not path else "/" + "/".join((*path, escape(label)))
                    quarantined[evidence_key] = child
                else:
                    clean[key] = walk(child, (*path, escape(label)))
            return clean
        if isinstance(value, list):
            return [walk(child, (*path, str(index))) for index, child in enumerate(value)]
        return value

    return {"tool": canon["tool"], "args": walk(canon.get("args") or {})}, quarantined


def forged_authority_claims(quarantined: dict) -> list[str]:
    """The subset of quarantined fields that assert authority the caller does
    not have. Truthy assertions only — an explicit `authorized: false` is not
    a forgery attempt."""
    out = []
    for k, v in quarantined.items():
        kl = str(k).strip().lower()
        leaf = kl.rsplit("/", 1)[-1].replace("~1", "/").replace("~0", "~") if kl.startswith("/") else kl
        if leaf not in _FORGERY_SIGNIFICANT and not is_authority_shaped(leaf):
            continue
        if isinstance(v, bool) and not v:
            continue
        if v in (None, "", 0):
            continue
        out.append(kl)
    return sorted(out)


# ─────────────────────────────────────────────────────────────
# Identity
# ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class Principal:
    """An authenticated actor. Constructed by the runtime from session state —
    never parsed out of a tool call."""

    id: str
    tenant: str = ""
    roles: frozenset = field(default_factory=frozenset)
    # Capabilities this principal may exercise WITHOUT a per-action approval.
    granted_capabilities: frozenset = field(default_factory=frozenset)

    def has_role(self, role: str) -> bool:
        return role in self.roles


ANONYMOUS = Principal(id="anonymous", tenant="", roles=frozenset(),
                      granted_capabilities=frozenset())


# ─────────────────────────────────────────────────────────────
# Approval artifacts
# ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ApprovalArtifact:
    """A verifiable grant to perform ONE specific canonical action.

    Bound to `action_hash`, so an approval obtained for a $100 transfer cannot
    be replayed against a $4,500,000 transfer: the hash differs, verification
    fails. This is what makes action-mutation-after-approval structurally
    impossible.
    """

    action_hash: str
    issuer: str
    scope: str = ""
    issued_at: float = 0.0
    expires_at: float = 0.0
    nonce: str = ""
    signature: str = ""

    def _payload(self) -> str:
        return "|".join([
            self.action_hash, self.issuer, self.scope,
            f"{self.issued_at:.0f}", f"{self.expires_at:.0f}", self.nonce,
        ])

    def sign(self, key: bytes) -> "ApprovalArtifact":
        # An empty key is not a key. HMAC accepts b"" happily and produces a
        # perfectly valid tag, which means anyone who knows the scheme could
        # mint approvals — so refuse to create the artifact at all rather than
        # hand back one that carries no authority but looks authoritative.
        if not key:
            raise ValueError(
                "refusing to sign an approval artifact with an empty key: "
                "configure GOVERNANCE_APPROVAL_KEY")
        sig = hmac.new(key, self._payload().encode(), hashlib.sha256).hexdigest()
        return replace(self, signature=sig)

    def verify(self, key: bytes, expected_action_hash: str,
               trusted_issuers: frozenset, now: float,
               seen_nonces: Optional[set] = None) -> tuple[bool, str]:
        """Constant-time signature check plus binding, expiry, issuer and
        replay checks. Returns (ok, reason)."""
        # FAIL CLOSED on an absent key. `hmac.new(b"", …)` is a valid HMAC, so
        # an unconfigured deployment would verify attacker-minted approvals —
        # re-opening the whole approval-bypass finding. No key means no approval
        # can ever verify, so no approval-based PERMIT can be produced.
        if not key:
            return False, ("approval verification is DISABLED: no approval "
                           "signing key is configured (set "
                           "GOVERNANCE_APPROVAL_KEY). Failing closed — no "
                           "approval can be accepted.")
        if not self.signature:
            return False, "approval artifact is unsigned"
        expect = hmac.new(key, self._payload().encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expect, self.signature):
            return False, "approval signature invalid"
        if self.action_hash != expected_action_hash:
            return False, (
                f"approval is bound to a different action "
                f"({self.action_hash[:12]}… != {expected_action_hash[:12]}…)")
        if trusted_issuers and self.issuer not in trusted_issuers:
            return False, f"approval issuer {self.issuer!r} is not trusted"
        if self.expires_at and now > self.expires_at:
            return False, "approval has expired"
        if seen_nonces is not None and self.nonce and self.nonce in seen_nonces:
            return False, "approval nonce already used (replay)"
        return True, "approval verified"


# ─────────────────────────────────────────────────────────────
# Security context
# ─────────────────────────────────────────────────────────────

@dataclass
class SecurityContext:
    """Server-side trust state. The ONLY source of authority.

    Constructed by the runtime from authenticated session state and deployment
    configuration. A tool call can never construct or mutate one.
    """

    principal: Principal = ANONYMOUS
    approvals: tuple = ()
    # Policy facts THIS DEPLOYMENT has established — a compliance sign-off its
    # own systems recorded, an operator confirmation, a clinical triage result.
    #
    # They are injected into the Ω evaluation namespace with TRUSTED
    # provenance, which is what lets a rule that requires an attestation be
    # satisfied. The same names arriving in a tool call's `args` carry
    # UNTRUSTED provenance and satisfy nothing, because an action asserting
    # that it is authorised is not an authorisation.
    #
    # This is trusted CONFIGURATION, like `approvals` and `trusted_issuers`:
    # it must be populated from something the deployment authenticated, never
    # forwarded from an agent, a peer message, or a request body. A service
    # that pipes caller input in here has re-created by hand the confusion the
    # field exists to prevent.
    trusted_facts: dict = field(default_factory=dict)
    signing_key: bytes = b""
    trusted_issuers: frozenset = field(default_factory=frozenset)

    # Trusted destination configuration (see kernel.destinations)
    internal_url_hosts: tuple = ()
    internal_email_domains: tuple = ()
    internal_cidrs: tuple = ()

    # Policy for tools with no declared capability manifest entry.
    # "escalate" (default) | "block" | "permit"
    unknown_tool_policy: str = "escalate"
    # Strict envelopes reject even nonmaterial caller authority assertions.
    reject_untrusted_authority_claims: bool = False
    # Declared tool manifest: {tool_name: [capability, ...]}
    tool_manifest: dict = field(default_factory=dict)

    # Policy-owned comparison values a caller must not choose.
    policy_values: dict = field(default_factory=dict)

    # ── authority continuity ─────────────────────────────────
    # Where this principal's governed history lives. `None` uses the
    # process-wide default store, which gives continuity across the sessions,
    # threads and workers inside one process. Configure a durable store
    # (FileContinuityStore, or your own ContinuityStore) for continuity across
    # restarts, hosts, and a distributed fleet.
    continuity_store: Any = None

    # Optional finer isolation WITHIN one principal, for genuinely independent
    # jobs. Part of the continuity key, so it must come from deployment
    # configuration — an agent that could set its own workload could rotate it
    # and re-open trajectory fragmentation.
    workload: str = ""

    # How far back governed history is considered, in seconds.
    #
    # Trajectory analysis over an UNBOUNDED past is neither safe nor useful: an
    # agent that once read customer data would have every future egress refused
    # for the life of the principal, so operators would widen the allowlists
    # until the control meant nothing. One hour is long enough that an attacker
    # cannot rotate sessions to escape it — session rotation is instant, waiting
    # is not — and short enough that yesterday's work does not govern today's.
    #
    # The trade-off is explicit and is the main residual limitation of the
    # continuity design: an attacker patient enough to spread one prohibited
    # trajectory across a window longer than this defeats it. Raise it for
    # high-value workloads; the cost is more escalations, not less safety.
    continuity_window_s: float = 3600.0

    # Deprecated: mrl1 keys are retained for configuration compatibility only.
    # Export requires an external Ed25519 signer and shared atomic registry.
    lease_signer: Any = None
    lease_store: Any = None
    lease_signing_key: bytes = b""

    # How many authorisations one identity may hold reserved-but-unexecuted.
    # Beyond this, further authorisation escalates until the caller executes or
    # releases. 0 disables the limit.
    max_outstanding_reservations: int = 64

    # What to do when the persistent identity cannot be established:
    # "escalate" (default) | "block" | "permit". "permit" is an explicit,
    # auditable opt-out, not a silent one.
    continuity_policy: str = "escalate"

    # Whether loopback / RFC1918 addresses count as inside the trust boundary
    # WITHOUT being named in `internal_url_hosts` or `internal_cidrs`.
    #
    # Defaults to False, which is a behaviour change: any private or loopback
    # literal used to resolve as internal automatically, so a collector on the
    # agent's own VPC was "internal" and every external-egress rule was skipped
    # for it. Deployments that genuinely trust their private ranges should list
    # them in `internal_cidrs`; this flag exists for the ones that cannot
    # enumerate them yet. Link-local and cloud metadata endpoints are never
    # internal, whatever this is set to.
    trust_private_networks: bool = False

    _used_nonces: set = field(default_factory=set)

    # ── approvals ────────────────────────────────────────────
    def verified_approval(self, expected_hash: str,
                          now: Optional[float] = None
                          ) -> tuple[Optional[ApprovalArtifact], str]:
        """Return the verified approval for this exact action, if any."""
        now = time.time() if now is None else now
        # Checked before anything else: without a signing key there is no way to
        # distinguish a real approval from a forged one, so the honest answer is
        # that approval-based authorisation is unavailable — not that the
        # approval passed.
        if not self.signing_key:
            return None, ("approval verification is DISABLED: no approval "
                          "signing key is configured (set "
                          "GOVERNANCE_APPROVAL_KEY). Failing closed.")
        if not self.approvals:
            return None, "no approval artifact presented"
        last = "no approval artifact presented"
        for art in self.approvals:
            ok, reason = art.verify(self.signing_key, expected_hash,
                                    self.trusted_issuers, now,
                                    self._used_nonces)
            if ok:
                return art, reason
            last = reason
        return None, last

    def consume_nonce(self, art: ApprovalArtifact) -> None:
        if art.nonce:
            self._used_nonces.add(art.nonce)

    def grants(self, capability: str) -> bool:
        return capability in self.principal.granted_capabilities

    def describe(self) -> dict:
        return {
            "principal": self.principal.id,
            "tenant": self.principal.tenant,
            "roles": sorted(self.principal.roles),
            "granted_capabilities": sorted(self.principal.granted_capabilities),
            "approvals_presented": len(self.approvals),
            "unknown_tool_policy": self.unknown_tool_policy,
            "manifest_tools": len(self.tool_manifest),
        }


def issue_approval(call: dict, issuer: str, key: bytes, ttl_s: float = 300.0,
                   scope: str = "", nonce: str = "",
                   now: Optional[float] = None) -> ApprovalArtifact:
    """Helper for trusted approval services (and tests): mint a signed approval
    bound to the SEMANTIC hash of `call`.

    Semantic rather than byte-canonical, so an approval is bound to the
    TRANSITION it was granted for. A reviewer who approves
    `shell {"cmd": "..."}` has approved that command; re-proposing it as
    `run_shell` is the same transition and consumes the same approval, rather
    than presenting as a new unapproved action or — worse — letting a second
    spelling escape the approval requirement entirely.

    Raises if `key` is empty — see `ApprovalArtifact.sign`.

    The call is canonicalised first, exactly as the kernel canonicalises a
    proposal before hashing it. Hashing the raw call made an approval for
    `amount: 1200.0` (as models emit it) unverifiable against the kernel's
    `amount: 1200`, so the approved action stayed ESCALATE.
    """
    from morrison_governance.kernel.canonical import canonicalize
    now = time.time() if now is None else now
    return ApprovalArtifact(
        action_hash=semantic_action_hash(canonicalize(call)), issuer=issuer, scope=scope,
        issued_at=now, expires_at=now + ttl_s, nonce=nonce,
    ).sign(key)
