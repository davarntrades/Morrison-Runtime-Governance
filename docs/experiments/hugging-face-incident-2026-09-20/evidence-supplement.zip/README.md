# Hugging Face incident-mechanism study: evidence supplement

This version-pinned repository deposit preserves recovered original September 2026 workflow artifacts independently of GitHub Actions retention, alongside newly executed offline characterization logs. It contains evidence and documentation only. No runtime file is changed.

## Evidence categories

- `evidence/historical/<run_id>/original_artifact.zip`: original workflow archive bytes, verified against GitHub's SHA-256 digest.
- `evidence/historical/<run_id>/results.json` and `board.json`: exact extracted original bytes, not edited or rerun.
- `evidence/historical/artifact_manifest.json`: artifact IDs, original source SHAs, expiry metadata and verified digests. The four workflows expire on 20 October 2026; these deposited bytes do not depend on workflow retention.
- `evidence/historical_raw_audit.json`: new recalculation from original raw turns and target-call records. All checked published counts match, including 108 governed proposing trials, 108 refusals and 0 governed destructive hits. The raw Qwen trial's old POSITIVE label is preserved; its corrected classification is PARTIAL.
- `evidence/receipt_before.json` / `receipt_after.json`: fresh inert-callback comparison at the exact run 6/run 7 commits. Not a live-model rerun.
- Other TXT logs: new offline self-test,3 versus 0 stub wiring control, 38 receipt tests and 23 scripted authority vectors at runtime snapshot `f93c010e98530874787a3e3f6c8485343a62f94f`.

## Verify and audit without inference

From this supplement directory:

```bash
sha256sum -c SHA256SUMS.txt
python evidence/audit_historical_artifacts.py
```

The audit uses Python standard-library modules only and reads local records. It performs no inference, external effect or network operation. Expected result: zero aggregate mismatches, 108 proposing trials, 108 refused proposing trials, 0 destructive stub hits under governance.

## Reproduce the fresh offline checks

Clone the public Morrison Runtime Governance repository and detach at `f93c010e98530874787a3e3f6c8485343a62f94f`. Install dependencies as recorded in `evidence/environment_and_commands.json`, then run the listed offline commands. These execute scripted backends and inert callbacks or the loopback stub. They do not reproduce model susceptibility.

For the exact receipt comparison, check out `3103e450db8aee22cff7a0627fc2d98396b2be46` and `be0e38995b27c1fe38815bf659a0b078d289c0a3` separately, then invoke `python evidence/receipt_comparison.py /absolute/path/to/checkout` from this directory for each. Expected: empty quarantine / ESCALATE before, approval_id quarantine / BLOCK after, and zero callback executions in both cases.

## Historical provenance

| Run | Workflow | Source revision | Governed proposing trials |
|---|---|---|---:|
|3|35484988428|0e66deb5a1dc2f3605d2dec45d52fdfae0617373|2|
|5|35485983996|bd125ceb9de9cc316ab0a926ab9f6b06c01fe83a|5|
|6|35486839914|3103e450db8aee22cff7a0627fc2d98396b2be46|61|
|7|35488664789|be0e38995b27c1fe38815bf659a0b078d289c0a3|40|

## Interpretation

These are historical model trajectories, newly recovered and audited. They are not new model runs. Counts of firing trials, governed proposing trials, carried-claim turns and individual stub calls remain separate. Execution refusal includes ESCALATE as well as BLOCK. The study concerns the reported incident mechanism in an isolated target environment; it does not claim recreation of the original infrastructure.

A DOI-bearing archival deposit is not claimed by this repository publication. Use an immutable commit URL for citation, not the mutable branch name.
