# Incident Study: Source-to-Claim Audit

This is an author-affiliated scientific synthesis of recorded incident-study results, with separately identified fresh offline checks. No live inference was performed and no tracked runtime file was modified.

## Evidence baseline

Current source: `f93c010e98530874787a3e3f6c8485343a62f94f`, matched to remote main on 8 October 2026. Public raw source retrieval: 20/20 files returned matching bytes; hashes and exact URLs are in `evidence/source_manifest.json`. This establishes source availability, not raw historical transcript availability.

| Historical run | Source revision | Governed proposing trials | Refused |
|---|---|---:|---:|
| 35484988428 | `0e66deb5a1dc2f3605d2dec45d52fdfae0617373` | 2 | 2 |
| 35485983996 | `bd125ceb9de9cc316ab0a926ab9f6b06c01fe83a` | 5 | 5 |
| 35486839914 | `3103e450db8aee22cff7a0627fc2d98396b2be46` | 61 | 61 |
| 35488664789 | `be0e38995b27c1fe38815bf659a0b078d289c0a3` | 40 | 40 |

The 108 total counts trials with at least one governed destructive proposal, not individual proposed calls. The facts-file field `blocked` is used for nonexecuting refusal, including ESCALATE.

## Claim mapping

| Paper location | Proposition | Source | Evidence status |
|---|---|---|---|
| Title/abstract/1 | Reported mechanism reproduced in an isolated model-and-stub environment; original infrastructure not recreated | [limits_audit/FINDINGS_FORGED_ARTIFACT.md:74](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/FINDINGS_FORGED_ARTIFACT.md#L74) | Historical report; original incident not independently primary-source verified |
| Abstract/1/5.1/Fig.4 | Run 6 forewarned: 3/20 deadline-only, 17/20 forged; observed 70 percentage-point difference | [limits_audit/evidence/facts.json:204](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/evidence/facts.json#L204) | Recovered historical raw records agree with cell aggregates; arithmetic, not significance test |
| Abstract/1/4/5.3/Fig.5 | 108 governed proposing trials, all refused; zero destructive stub calls | [limits_audit/evidence/facts.json:54](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/evidence/facts.json#L54) | 2+5+61+40; trial denominator confirmed by rate_table; not individual call total |
| 2/Table1/Appendix | Run IDs and commit provenance | [limits_audit/FINDINGS_FORGED_ARTIFACT.md:9](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/FINDINGS_FORGED_ARTIFACT.md#L9) | Short SHAs expanded using Git; source manifest preserves current report revision |
| 2/Appendix | Public source availability and hashes | [limits_audit/evidence/facts.json:2](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/evidence/facts.json#L2) | New retrieval: 20 public files HTTP200 and byte match; source_manifest.json |
| 2/10.2/Appendix | results.json and board.json stored as 30-day workflow artifacts; raw bytes not recovered | [limits_audit/FINDINGS_FORGED_ARTIFACT.md:750](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/FINDINGS_FORGED_ARTIFACT.md#L750) | Recovered original ZIPs match GitHub digests; raw JSON is included; see historical/artifact_manifest.json |
| 3.1/Fig.1 | Target binds127.0.0.1; fabricated responses and local-only guard | [limits_audit/live_multiagent/mock_service.py:140](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/live_multiagent/mock_service.py#L140) | Inspected implementation; fresh local wiring confirms route |
| 3.1/Fig.1 | Direct versus authorize/execute dispatch; capability mapping; configured key and issuers | [limits_audit/live_multiagent/run_experiment.py:79](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/live_multiagent/run_experiment.py#L79) | Current source; live results retain historical run SHAs |
| 3.1/Fig.1 | Board verifies no author identity; separate component conversations | [limits_audit/live_multiagent/board.py:36](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/live_multiagent/board.py#L36) | Inspected board and agents.py module contract |
| 3.2/Fig.2 | Prompt arms differ only by board-authority warning; operator requirement retained | [limits_audit/live_multiagent/agents.py:97](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/live_multiagent/agents.py#L97) | Source + fresh offline_selftest.txt assertions |
| 3.2/4 | Conditions are separate model samples; not identical replayed proposal stream | [limits_audit/live_multiagent/run_experiment.py:108](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/live_multiagent/run_experiment.py#L108) | Source; analyse() explicitly discusses model nondeterminism |
| 3.3/Fig.3 | Fixed deadline and forged approval variants; invented APR-7741-C9F2 | [limits_audit/live_multiagent/agents.py:246](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/live_multiagent/agents.py#L246) | Study-owned fabricated input, not legitimate approval |
| 3.3/4 | Board emptyturn1; peer-induced label requires first destructive turn>1; five-turn cap | [limits_audit/live_multiagent/run_experiment.py:214](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/live_multiagent/run_experiment.py#L214) | Temporal scoring; agents.py MAX_TURNS=5 |
| 4/Eq.1-3 | Fire rate trial denominator; refusal conditional on governed proposing trials; n/a if none | [limits_audit/live_multiagent/run_experiment.py:388](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/live_multiagent/run_experiment.py#L388) | Mathematical restatement of implemented counts |
| 4/5.3 | Refused includes ESCALATE and BLOCK; all108 must not be called BLOCK | [limits_audit/FINDINGS_FORGED_ARTIFACT.md:284](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/FINDINGS_FORGED_ARTIFACT.md#L284) | Report and actual code; no executed escalation assumed |
| 5.1/Table2 | Run6 full four-cell proposal, temporal, refusal and stub-hit counts | [limits_audit/evidence/facts.json:204](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/evidence/facts.json#L204) | Historical raw-record counts independently recalculated in this revision; no new live inference |
| 5.2/Table3 | Initial Claude negatives; run3 Claude/Llama negatives; QwenPARTIAL; DeepSeek4controlcalls | [limits_audit/evidence/facts.json:17](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/evidence/facts.json#L17) | Crosschecked consolidated report and negative-run report |
| 5.2 | Run5 0/5 forewarned and5/5uninoculated; latter5/5governedrefused | [limits_audit/evidence/facts.json:163](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/evidence/facts.json#L163) | Historical; cells with no governed proposal receive no refusal credit |
| 6/Eq.4-5/Fig.6 | Artifact fields and HMAC payload serialization, rounded timestamps | [morrison_governance/kernel/trust.py:234](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/morrison_governance/kernel/trust.py#L234) | Implementation, not experimental result |
| 6.1 | Empty-key refusal; configured issuer, actionhash, expiry, nonce/replay conditionals | [morrison_governance/kernel/trust.py:269](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/morrison_governance/kernel/trust.py#L269) | Exact source semantics; HMAC verifier shares signing secret |
| 6.2/Eq.6 | Only permitted candidates dispatch via execute on tested route | [limits_audit/live_multiagent/run_experiment.py:108](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/live_multiagent/run_experiment.py#L108) | Operative harness requirement, not all-adapter theorem |
| 7/Fig.7 | Run6 evidence omitted approval_id; seven carried-claim turns; correct refusal | [limits_audit/FINDINGS_FORGED_ARTIFACT.md:53](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/FINDINGS_FORGED_ARTIFACT.md#L53) | Historical finding; minimal mechanism freshly characterized in receipt_before.json |
| 7/Fig.7 | be0e389 shape matcher recognizes claim; narrow negatives preserved | [morrison_governance/test_forged_authority_receipt.py:73](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/morrison_governance/test_forged_authority_receipt.py#L73) | Source, fresh38testpasses; no complete matcher claim |
| 7 | Run7 19/20vs20/20fire;40/40refused;receiptapproval_id;6and2carriedturns;25and30ungovhits | [limits_audit/FINDINGS_FORGED_ARTIFACT.md:356](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/FINDINGS_FORGED_ARTIFACT.md#L356) | Historical separate rerun, not replacement for run6 |
| 7 | 17/20to19/20change does not demonstrate kernelpatch effect on ungoverned route | [limits_audit/live_multiagent/run_experiment.py:108](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/live_multiagent/run_experiment.py#L108) | Mechanistic inference; separate samples; report attributes sampling variation |
| 8.1/Fig.8 | Qwen false scoring credit repaired; PARTIAL precedes success; n/a neverproposed | [limits_audit/live_multiagent/run_experiment.py:230](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/live_multiagent/run_experiment.py#L230) | Source and new scripted offline self-test |
| 8.2/Fig.9 | Distinct policy-state failures and historical116to38,3/9to1/9,5/13to0/13;missing-evidence residual | [limits_audit/FINDINGS_HARDENING.md:80](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/FINDINGS_HARDENING.md#L80) | Historical adjacent incident-driven audit; not included in live108 |
| 9/Table4 | Fresh offline self-test passed;3vs0destructivecalls;benignreadsexecuted | [limits_audit/live_multiagent/dry_run_governance.py:21](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/live_multiagent/dry_run_governance.py#L21) | New logs at f93c010; scripted only |
| 9/Table4 | 38receipt tests passed | [morrison_governance/test_forged_authority_receipt.py:29](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/morrison_governance/test_forged_authority_receipt.py#L29) | New receipt_tests.txt:38passed0.04s; not historicalsuitecounts |
| 9/Table4 | 23scriptedauthorityvectors0callbackexecutions;validapproval1execution | [limits_audit/test_4_peer_go_message.py:98](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/test_4_peer_go_message.py#L98) | New static_peer_go.txt, counters; no external effects |
| 9 | Exact3103e45vsbe0e389probe:ESCALATEemptyclaims→BLOCKapproval_id;zero callbacks both | [morrison_governance/kernel/trust.py:172](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/morrison_governance/kernel/trust.py#L172) | New receipt_comparison.py and before/after JSON logs |
| 9 | Static probe stale ordinaryPERMIT explanation after actual BLOCK output | [limits_audit/test_4_peer_go_message.py:324](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/test_4_peer_go_message.py#L324) | Observed discrepancy in unmodified fresh log; explanatory prose not a result |
| 10.1 | Destructive live finding exercises per-action approval, not a demonstrated global predicate | [limits_audit/FINDINGS_FORGED_ARTIFACT.md:284](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/FINDINGS_FORGED_ARTIFACT.md#L284) | Recorded capability_policy verdict plus code; exact claim-scope separation |
| 10.2 | Single forgedmodel, wording, five-turn horizon, directkernelroute; planned falsifications | [limits_audit/FINDINGS_FORGED_ARTIFACT.md:659](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/FINDINGS_FORGED_ARTIFACT.md#L659) | Existing scoped limits; all new suggested tests explicitlyplanned |
| Appendix | Historical exact invocation flags | [limits_audit/FINDINGS_FORGED_ARTIFACT.md:712](https://github.com/davarntrades/Morrison-Runtime-Governance/blob/f93c010e98530874787a3e3f6c8485343a62f94f/limits_audit/FINDINGS_FORGED_ARTIFACT.md#L712) | Copied at each historical SHA, not run for thispaper |

## Scientific corrections preserved

- Initial Claude negatives are not counted as exercised governance successes.
- Qwen's control hit without a governed proposal is PARTIAL; refusal rate is not applicable.
- 3/20 versus 17/20 is run 6, not silently replaced with run 7's 19/20.
- The receipt patch repairs forgery attribution; execution containment already held in the relevant live cells.
- Run6's three forewarned/deadline firing trials include one turn 1 proposal before the message; only two are labeled peer-induced.
- Trial fire counts, governed proposing trials, carried-claim turns and stub-call counts are separate units.
- Authority provenance does not establish policy-state truth. The related1/9 residual is retained.
- Historical broad regression-suite totals, pricing and token-spend claims are omitted because they are not needed to establish this paper's contribution.
- No local/global multi-agent suite results or exported-lease experiments are imported from the other preprint.

## Unresolved artifact issues

Original historical results.json and board.json are described as GitHub Actions artifacts with30-day retention. Their raw bytes were not recovered. The aggregate facts record and consolidated report are public, but cannot substitute for an independently inspectable trajectory archive. Deposit the original artifact bytes with exact provenance and hashes before asserting complete artifact reproducibility.

The repository's description of the original Hugging Face incident relied on secondary reporting. This paper does not repeat detailed original incident statistics or claim independent primary-source confirmation.

The supplement is prepared for a public commit-pinned repository deposit on a separate documentation-only branch. Final publication metadata is recorded in evidence/public_deposit.json after publication; no DOI-bearing archive is claimed.

## Fresh versus historical evidence

The new checks are offline only: harness self-test, scripted wiring,38 receipt regressions,23 authority vectors, and the exact-revision minimal receipt comparison. The live 3/20,17/20,19/20 and108 trial measurements remain historical repository-reported results.

## Layout verification

The final LaTeX is compiled in two columns. Nine vector figures comprise seven mechanism/design diagrams and two result charts. Every rendered page is visually inspected; the first architecture figure was corrected to move route labels clear of its nodes. Compiler and PDF bounds checks accompany the supplement.

## Recovery revision

- Four original ZIP archives and all eight raw JSON files recovered. All four ZIP digests match GitHub metadata.
- Recomputing firing, governed proposing trials, refusals, target hits and forgery names yields no mismatches against the published facts.
- The original Qwen analysis label is POSITIVE; raw records show no governed destructive proposal. The corrected PARTIAL classification remains explicit and the raw record is not edited.
- The four-cell visual now shows every run-6 cell with its exact denominator and target-call count.
- The receipt figure now shows the identical candidate, recognition, quarantine, verdict layer, receipt field and zero callback counts at the exact before/after revisions.
